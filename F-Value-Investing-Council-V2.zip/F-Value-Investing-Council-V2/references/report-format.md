# 报告版式规范（固定，v1.0）

> 这是**唯一**的报告呈现标准。所有 HTML 报告一律按此出，不再每次现调。
> 配套文件：`report-shell.css`（样式底座，整段复制）、`scripts/gen_donut.py`（环形图生成器）。
> 改动本规范需在文末「版本记录」留痕，并同步改 `report-shell.css`。

---

## 一、文件骨架（照抄）

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>标题 · 副标题（日期）</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
/* ← 把 references/report-shell.css 全文粘在这里，不要改写 */
</style>
</head>
<body>
<div class="wrap">
  <header class="hero"> … </header>
  <div class="sec"><span class="num">01</span><h2>…</h2><span class="hint">…</span></div>
  <div class="panel"> … </div>
  …
  <div class="disclaimer"> ⚠️ 免责声明 </div>
</div>
<script>
/* ← Chart.js 实例，见第四节 */
</script>
</body>
</html>
```

单文件、零本地依赖（仅 Chart.js 走 CDN）。文件落在 `任意输出目录/<名称>.html`。

---

## 二、设计令牌（勿改）

| 用途 | 变量 | 值 |
|---|---|---|
| 页面底 | `--bg` | `#0B0B0D` |
| 卡片 | `--panel` | `#141418` |
| 抬升区 / 表头 / KPI 卡 | `--panel2` | `#1A1A1F` |
| 分隔线 | `--line` | `rgba(255,255,255,.07)` |
| 正文 | `--txt` | `#EDEAE6` |
| 次要 | `--muted` | `#94949E` |
| 强调（品牌） | `--gold` | `#E8A33D` |
| 涨 / 风险 | `--red` | `#F87171` |
| 跌 / 安全 | `--green` | `#4ADE80` |
| 科技 / 互联网 | `--blue` | `#60A5FA` |
| 红利 / 防守 | `--purple` | `#A78BFA` |
| 资源 / 周期 | `#34D399` | 直接写色值 |
| 圆角 | `--radius` | `18px` |

**字号阶梯**：h1 34 / h2 22 / h3 18–19 / h4 15 / 正文 16.5–17 / 表格 15 / 注释 13.5–14。
**行高**：正文 1.7–1.9，表格 1.6。
**数字**：全站 `font-variant-numeric: tabular-nums`（否则纵向对不齐）。

> ⚠️ **A 股配色，红涨绿跌，不可反**。风险提示用红，安全信号用绿。

---

## 三、组件库（直接取用）

### 3.1 Hero：柔和引入，**禁止**开门直接甩结论

```html
<header class="hero">
  <div class="hero-top">
    <div>
      <div class="eyebrow">报告类型 · 出处</div>
      <h1>主标题，<span>金色高亮的后半句</span></h1>
    </div>
    <div class="datechip"><b>2026-10-26</b>盘中快照</div>
  </div>
  <p class="hero-lead">
    一两句话交代「先看什么、再拆什么」，<b>加粗关键词</b>，<b class="hl">金色点睛</b>。
    结论放最后，过程摆前头。
    若本次是改版，引入语末句要**点名新增了什么**，否则读者翻不到。
  </p>
  <div class="hero-kpis">
    <div class="hk">
      <div><div class="n gold">42.8%</div><div class="l">KPI 名称</div></div>
      <div class="s" style="color:var(--muted)">副注</div>
    </div>
    <!-- ×4，固定 4 个 -->
  </div>
</header>
```

规则：Hero KPI **固定 4 个**；引入语 2–3 句、不列数据表；`.hl` 只点一处。

### 3.1.1 篇首导航条 TOC（Hero 内末尾，必带）

多节报告（≥4 节）一律在 Hero 底部加一条导航，作用有二：一是让人一眼看到全篇结构，二是**改版时能标出新增章节**，避免"我加了模块但对方没看见"。

```html
<nav class="toc">
  <span class="toc-lbl">本篇结构</span>
  <a href="#s1"><span class="ti">01</span>配置总览</a>
  <a href="#s2"><span class="ti">02</span>流动性周期</a>
  <a href="#s3"><span class="ti">03</span>重点诊断</a>
  <a href="#s4"><span class="ti">04</span>跨资产发现</a>
  <a href="#s5"><span class="ti">05</span>触发线汇总</a>
</nav>
```

配套：每个章节头写成 `<div class="sec" id="s2">`（id 与 `href` 对应）。

规则：① 一条横排，放不下就 `flex-wrap` 换行，不许横向滚动；② `.new` 徽章只在改版时标新增那节，常态报告全部去掉；③ 文字用短名（4–6 字），不要在导航里写副标题；④ 导航后紧跟 01 节，不要插别的块。

### 3.2 Section 分隔

```html
<div class="sec"><span class="num">01</span><h2>标题</h2><span class="hint">右侧小注</span></div>
```

编号从 01 起，全篇 ≤ 6 节。

### 3.3 Panel / Panel-head

```html
<div class="panel">
  <div class="panel-head"><h3>小标题</h3><span class="cap">右侧说明</span></div>
  …
</div>
```
紧凑表格区用 `.panel.tight`。

### 3.4 KPI 卡（三/四列）

```html
<div class="kpis four">
  <div class="kpi"><div class="n gold">29.4%</div><div class="l">名称</div></div>
</div>
```
**必须**保持 `min-height:112px` 与 `justify-content:space-between`，否则卡片高低不齐。

### 3.5 重点资产卡（左色条）

```html
<div class="panel asset" style="--accent:var(--red)">
  <div class="asset-head">
    <div><div class="rank">01 · 类别</div><h3>名称（代码）</h3></div>
    <div style="text-align:right">
      <div class="val">29.2% · ¥328.4万</div>
      <div class="cap" style="font-size:12.5px;color:var(--muted);margin-top:3px">持股明细</div>
    </div>
  </div>
  <div class="sub">
    <h4>小标题：一句判断</h4>
    <p>正文…</p>
  </div>
  <div class="quote"><b>一句话结论（流派交集）</b>：…</div>
</div>
```
每张资产卡 **3–5 个 `.sub`**，末尾 **1 个 `.quote`**。

### 3.6 文字块 `.sub`（重点分析的唯一载体）

```html
<div class="sub">
  <h4>价格与估值：一句可记住的判断</h4>
  <p>正文。<span class="nm">巴菲特认为</span>，…</p>
  <p>第二段，补充反面或边界条件。<span class="warn">风险点</span>…</p>
</div>
```
`.nm` = 人物/流派署名（金色）；`.warn` = 风险点（红色）。

### 3.7 引用结论 `.quote`

```html
<div class="quote"><b>一句话结论（段永平 + 巴菲特交集）</b>：…</div>
```

### 3.8 进度条

```html
<div class="bar-row"><span>标签</span>
  <div class="bar-track">
    <div class="bar-fill" style="width:29.2%;background:linear-gradient(90deg,#b34a4a,var(--red))">29.2%</div>
  </div>
</div>
```
浅色条用 `.bar-fill.dark`（正文色文字）。

### 3.9 表格

```html
<div class="tbl-wrap">
<table>
  <thead><tr><th style="width:16%">列</th>…</tr></thead>
  <tbody><tr><td>…</td><td class="mute">…</td></tr></tbody>
</table>
</div>
```
- 必包 `.tbl-wrap`（提供横向滚动 + 圆角）
- `thead th` 用 `style="width:%"` 固定列宽，合计 100%
- 数字列 `style="text-align:right"`
- 长文本单元格**禁止** `white-space:nowrap`
- 语义色用 `td .up / .down / .gold / .mute`

### 3.10 流动性三件套（尺寸条 + 三色信号卡 + 敏感度映射表）

**GLI 刻度条**：一条 0–100 的渐变色带，白针标当前读数。区间必须与阈值对齐：`0–40` 红、`40–60` 金、`60–100` 绿。

```html
<div class="gbar"><div class="gmark" style="left:35%"><span>GLI 35</span></div></div>
<div class="glbl"><span style="left:0">0</span><span style="left:40%">40</span>
  <span style="left:60%">60</span><span style="left:100%">100</span></div>
```

- `left:%` = 读数本身（GLI 35 → `left:35%`），不要手动微调。
- 刻度标签**只写数字**。写成「40 · 黄灯线」这种长文本会因 `translateX(-50%)` 显得落点偏移，区间含义交给下面的三色卡表达。
- 气泡 `.gmark span` 需要上方 ≥36px 空白，故 `.gbar` 自带 `margin-top:40px`，别在同一 panel 里压紧。

**三色信号卡**：三张等高卡，当前状态那张加 `.on`（描边 + 底色）+ 「当前」白底徽章。

```html
<div class="sig">
  <div class="card on" style="color:var(--red)">
    <div class="hd"><span class="dot"></span>红灯<span class="now">当前</span></div>
    <div class="th">GLI &lt; 40</div>
    <div class="ds">动荡期。离岸成长股集体杀估值，降最敏感的一端。</div>
  </div>
  <div class="card" style="color:var(--gold)">…黄灯 40 ≤ GLI ≤ 60…</div>
  <div class="card" style="color:var(--green)">…绿灯 GLI &gt; 60…</div>
</div>
```

- 卡片靠 `style="color:…"` 驱动 `dot` 与描边（都用 `currentColor`）。
- ⚠️ **`.now` 徽章不要用 `background:currentColor`**：它自身的 `color` 是深色，会渲染成「黑底黑字」的椭圆。固定用 `background:#fff;color:#0B0B0D`。

**敏感度映射表**：把框架的 7 档敏感度落到自己的组合，必须带「组合对应」与「占比」两列，否则这张表对读者没有信息量。

| 敏感度 | 资产类型 | 绿灯期 | 红灯期 | 组合对应 | 占比 |
|---|---|---|---|---|---|
| 最敏感 | 离岸成长（港股互联网 / AI / 半导体） | 戴维斯双击 | 集体杀估值 | 逐项列出标的 | 按市值加权 |
| 高 | 国内成长（A 股科技） | 估值扩张 | 承压 | … | … |
| 中高 | 有色 / 商品 | 受益 | 承压 | … | … |
| 反向 | 黄金 | 实际利率下行最受益 | 实际利率上行承压 | … | … |
| 中 | 能源 | 温和受益 | 相对抗跌 | … | … |
| 低 | 红利 / 低波 | 通常跑输 | 相对抗跌 | … | … |
| 无 | 现金 | 机会成本 | 期权价值（弹药） | … | … |
| 框架外 | 水泥 / 电力 / 银行 | — | — | 按周期近似，须注明 | … |

- 框架没有对应项的资产（水泥、电力、银行）单列「框架外」行，**不要硬塞**进有色或红利，注明「按周期近似」即可。
- 表头 cap 写「按市值加权 · 四舍五入至 0.1%」，避免读者把 99.9% 当成算错。

### 3.11 免责声明

```html
<div class="disclaimer">
⚠️ 以上内容由 AI 基于公开信息与一手语料整理生成，仅供参考，不构成任何投资建议或个股推荐。投资有风险，决策需谨慎。<br><br>
数据时点 …；行情来源 …；估值口径 …。
</div>
```

---

## 四、图表规范

### 4.1 占比图 → **手写 SVG 环形图 + 引线外标注**（不用 Chart.js doughnut）

```bash
python3 scripts/gen_donut.py -i segs.json -o donut.svg --check
```
```html
<div class="panel">
  <div class="panel-head"><h3>占比分布</h3><span class="cap">引线标注 = 名称 / 占比 / 市值</span></div>
  <div class="donut-wrap">
    <!-- donut.svg 内容粘在这里 -->
  </div>
  <p class="chart-note">一句话点评，<b>关键词加粗</b>。</p>
</div>
```

**为什么不用 Chart.js**：它只能把图例堆在底部/侧面，字号受限且小到看不清；图例在右侧时还会把饼挤到左边缘贴边。手写 SVG 才能做到「每个扇区拉一条引线、旁边大字标注」。

**硬约束**：
- 容器 `.donut-wrap`（`max-width:880px` + `aspect-ratio:920/520` + 居中），**不要**用整页宽度——饼会显小、两侧空荡
- 标签字号：名称 19.5px / 占比 18.5px / 金额 15.5px
- 标签分左右两侧自动避让，最小间距 60px
- 必须跑 `--check`，**越界 0、重叠 0** 才能交付

### 4.2 对比 / 排名图 → Chart.js 横向或纵向柱状

```js
Chart.defaults.color = '#B9B7B2';
Chart.defaults.font.size = 13;
Chart.defaults.font.family = '-apple-system,"PingFang SC","Microsoft YaHei",sans-serif';
const GOLD='#E8A33D',UP='#F87171',DOWN='#4ADE80',BLUE='#60A5FA',PURPLE='#A78BFA',GREEN='#34D399',GRAY='#6E6E78',LIFT='#1A1A1F';
const grid={color:'rgba(255,255,255,.06)'};

// 实际 vs 目标（纵向分组柱）
new Chart(document.getElementById('cTarget'),{
  type:'bar',
  data:{labels:['A','B','C'],
    datasets:[
      {label:'实际 %',data:[29.4,5.9,19.2],backgroundColor:[GOLD,PURPLE,BLUE],borderRadius:6,barPercentage:.55},
      {label:'目标 %',data:[30,20,10],backgroundColor:'#34343c',borderRadius:6,barPercentage:.55}
    ]},
  options:{maintainAspectRatio:false,
    scales:{y:{max:35,grid,ticks:{color:'#94949E'},title:{display:true,text:'占组合 %',color:'#94949E'}},
            x:{grid:{display:false},ticks:{color:'#B9B7B2'}}},
    plugins:{legend:{position:'top',labels:{boxWidth:10,boxHeight:10,padding:14}}}}
});

// 市值排名（横向条）
new Chart(document.getElementById('cSector'),{
  type:'bar',
  data:{labels:['A','B','C'],
    datasets:[{label:'市值 (万元)',data:[482,331,162],
      backgroundColor:[BLUE,GOLD,GREEN],borderRadius:6,barPercentage:.7}]},
  options:{maintainAspectRatio:false,indexAxis:'y',
    scales:{x:{grid,ticks:{color:'#94949E'},title:{display:true,text:'万元',color:'#94949E'}},
            y:{grid:{display:false},ticks:{color:'#B9B7B2'}}},
    plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>` ${c.parsed.x} 万`}}}}
});
```

**铁律**：每张 Chart.js 图都必须 `maintainAspectRatio:false`，且父容器 `.chart`（300px）/`.chart.sm`（250px）给固定高度。
否则图会按默认宽高比缩在容器一角、留白不均。

### 4.3 图表数量：**重点分析部分不放图**

第一页（结构总览）可以有 3–4 张图；**逐个资产的深度诊断只用文字 + 表格**。
理由：图表适合看比例与排名，不适合承载论证；一个资产讲清「生意本质 / 估值 / 资本配置 / 周期位置 / 仓位纪律」需要的是段落，不是柱状图。

---

## 五、文字规范

### 5.1 观点必须先署名（最高优先级）

写出任何**判断 / 评论 / 诊断结论之前**，先点明这是谁（哪个流派）的观点：

- 单一来源 → 「**巴菲特认为**，…」「**芒格的方法**是…」「**段永平认为**，…」「**马克斯在备忘录中写道**，…」「**达利欧认为**，…」「**施洛斯的做法**是…」
- 多人共识 → **不许**写「价值投资认为」「有人认为」。点出**最权威、最有名的代表人物**，再补一句「XX、YY 亦持相同看法」。
- 示例：
  - ❌ 「好公司应该长期持有。」
  - ✅ 「**巴菲特与芒格认为**，高 ROIC + 宽护城河的好公司值得长期持有；**段永平亦强调**『买股票就是买公司』，与之一脉相承。」

实现上用 `<span class="nm">人名</span>` 上金色，一眼可辨。

### 5.2 单个资产写五个维度（缺一不可）

| 维度 | 要回答的问题 |
|---|---|
| **生意本质** | 钱从哪来？护城河在哪一层？怎么才会被摧毁？ |
| **价格与估值** | 现在多少倍？倒过来是多少盈利收益率？历史什么分位？ |
| **资本配置** | 留存的一元钱能不能创造超过一元钱市值？回购/分红/减持怎么看？ |
| **趋势位置** | 从高点回撤多少？处在钟摆的哪一侧？驱动因素是真伤还是擦伤？ |
| **仓位纪律** | 占比多少？超没超上限？加减的约束是价格还是仓位？ |

每个维度 **1–2 段**，每段 3–5 行；段落里必须有**具体数字**，不能只有形容词。

### 5.3 一句话结论

每张资产卡末尾一个 `.quote`，格式：`<b>一句话结论（A + B 交集）</b>：判断 + 立刻可执行的约束条件`。

### 5.4 不得出现的东西

- 「综合来看」「总体而言」这类无署名、无信息量的过渡句
- 指令性措辞（买入 / 卖出 / 加仓 / 清仓）→ 改用「偏多 / 偏空 / 观望 / 分歧」+ 触发线
- 未标来源的数字
- 预测式断言（「明年一定涨」）→ 改为条件句（「若 X，则 Y」）

---

## 六、报告骨架（章节节奏）

```
Hero（引入 + 4 个 KPI + 日期徽章 + 篇首导航 TOC）
01 配置/结构总览   —— 占比环形图 + 实际vs目标 + 排名 + 集中度进度条
02 流动性周期      —— GLI 刻度条 + 三色信号卡 + 三层监控表 + 敏感度映射表   ★固定章节
03 重点对象逐个诊断 —— 按权重降序，每项一张 asset 卡（5 维度 + 明细表 + 一句话结论）
04 一个跨对象的发现 —— 只有数据摆开才看得出的结构性问题（1 张表 + 2–3 段）
05 触发线汇总       —— 5 列表：对象 / 当前 / 上行触发 / 下行警戒 / 流派锚定（首行固定为「流动性总开关」）
免责声明
```

章节编号用 `01–05`；超过 6 节说明内容该合并了。

**02 流动性周期为什么必须排在重点诊断之前（不可调序）**：

- 逻辑顺序是「先定大方向 → 再看个股」。反过来最容易在退潮期把「便宜」误当成「该买」。
- 它给 03 的每项资产提供了一个**外部坐标**：同一份盈利，水宽给高 PE、水紧给低 PE，估值扩张与收缩本质是分母在动。
- 它常常与 01 的结构诊断**互相印证**。两个互不相干的框架指向同一个短板时，那个短板就从「观点」升级成「结构问题」——这是整份报告最有说服力的一段，务必写出来。
- 框架本体、阈值、指标清单、过滤规则全部见 `references/08-liquidity-cycle.md`；本节只做**呈现**，不复述方法论全文。

**呈现要点**（细化见 3.11 / 3.12）：

- 开头一段「为什么先看这一层」，把分母/分子的逻辑讲清，不要直接甩指标。
- 刻度条 + 三色卡承担「当前在哪」；三层监控表承担「怎么跟踪」；敏感度映射表承担「我的组合站在哪一端」。
- 读数必须标注**口径与时间**（谁家的 GLI、哪个时点、什么频率），季度指标不许写成日度结论。
- 若框架内部存在张力（例：Howell 一方面说流动性下行杀长久期，另一方面说中国是例外、PBOC 在扩张），**必须两面都写**，并指出这对组合意味着「两股力量交汇」而非单向顺风。

---

## 七、交付前自检清单（逐条过，不通过不交付）

```bash
# 1) 结构对应：canvas 与 getElementById 数量必须一致
grep -o '<canvas id="[^"]*"' 报告.html
grep -o "getElementById('[^']*')" 报告.html

# 2) 每张 Chart.js 图都填满容器
grep -c "maintainAspectRatio:false" 报告.html      # 应等于 canvas 数

# 3) 环形图几何自检
python3 scripts/gen_donut.py -i segs.json -o donut.svg --check   # 越界 0 / 重叠 0

# 4) 数字自洽：分项合计 = 总数
python3 -c "d=[...]; print(sum(d), 总数, sum(d)-总数)"           # diff 必须为 0

# 5) 视觉自检（必须做，不能只看代码）
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --headless=new --disable-gpu --no-sandbox --hide-scrollbars \
  --window-size=1200,14000 --screenshot=/tmp/page.png "file:///绝对路径/报告.html"
# 然后用 PIL 裁剪分段，逐块肉眼看：图表有没有空白、卡片有没有错位、
# 表格有没有被裁、饼图有没有贴边、文字有没有重叠。
```

**静态检查全过 ≠ 可以交付**。之前「饼图贴边」的返工就是因为只看了代码没看渲染结果。

---

## 八、版本记录

| 版本 | 日期 | 变更 |
|---|---|---|
| v1.0 | 2026-10-26 | 首版固化。确立：Hero 柔和引入 / 编号分区 / 统一栅格 / 统一 min-height / 数字等宽对齐 / 环形图改 SVG 引线外标注 / 重点资产走文字不走图 / 观点先署名 / 交付前必须截图自检 |
