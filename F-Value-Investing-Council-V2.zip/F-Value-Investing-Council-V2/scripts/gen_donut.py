#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_donut.py — 环形图（引线外标注）生成器 v1.0
固定版式配套脚本。

为什么不用 Chart.js 的 doughnut：
  Chart.js 只能把图例堆在底部或侧面，字号受容器限制、小到看不清，
  图例在右侧时还会把饼挤到左边缘贴边。故改为手写 SVG + 引线外标注。

用法：
  python3 gen_donut.py --input segs.json --out donut.svg
  python3 gen_donut.py --input segs.json --out donut.svg --check
  echo '{"center":"¥100万", ...}' | python3 gen_donut.py --out donut.svg

segs.json 格式：
  {
    "center": "¥100万",          # 圆环中心大字（必填）
    "center_label": "总资产",       # 中心小标签（默认"合计"）
    "sub": "2026-10-26 盘中快照",   # 中心脚注（可省）
    "segments": [
      {"name": "核心权益", "value": 380000, "color": "#60A5FA"},
      {"name": "现金流防守", "value": 240000, "color": "#A78BFA"}
    ]
  }

颜色缺省时按顺序取 PALETTE。
输出可直接粘进 .donut-wrap 容器：<div class="donut-wrap"><svg .../></div>
"""
import argparse, json, math, sys

# 版式常量（改动需同步 07-report-format.md）
CX, CY = 460, 255      # 环形中心
R, r = 136, 84         # 外半径 / 内半径
ELB = 170              # 引线拐点半径
XL, XR = 292, 628      # 左 / 右标签锚点 x
GAP = 60               # 同侧标签最小垂直间距
LO, HI = 48, 468       # 标签 y 的可用区间（viewBox 高 520）
VB_W, VB_H = 920, 520

PALETTE = ["#E8A33D", "#F87171", "#60A5FA", "#34D399", "#A78BFA", "#6E6E78"]


def fmt_amount(v, total):
    """按量级决定单位：过亿用亿，其余用万。"""
    if total >= 1e8:
        s = v / 1e8
        return f"{s:.2f}亿" if s < 10 else f"{s:.1f}亿"
    w = v / 1e4
    if w >= 10 or abs(w - round(w)) < 0.05:
        return f"{w:.0f}万"
    return f"{w:.1f}万"


def build(cfg):
    segs = cfg["segments"]
    total = sum(float(s["value"]) for s in segs)
    if total <= 0:
        raise SystemExit("segments 的 value 合计必须 > 0")

    items, ang = [], -90.0
    for i, s in enumerate(segs):
        v = float(s["value"])
        pct = v / total * 100
        span = pct / 100 * 360
        items.append(dict(
            name=s["name"], val=v, pct=pct,
            color=s.get("color") or PALETTE[i % len(PALETTE)],
            a1=ang, a2=ang + span, mid=ang + span / 2,
        ))
        ang += span

    def pt(rad, deg):
        return (CX + rad * math.cos(math.radians(deg)),
                CY + rad * math.sin(math.radians(deg)))

    # ---- 扇区 path ----
    for it in items:
        a1, a2 = it["a1"], it["a2"]
        large = 1 if (a2 - a1) > 180 else 0
        o1, o2 = pt(R, a1), pt(R, a2)
        i2, i1 = pt(r, a2), pt(r, a1)
        it["path"] = (f"M{o1[0]:.2f},{o1[1]:.2f} A{R},{R} 0 {large} 1 {o2[0]:.2f},{o2[1]:.2f} "
                      f"L{i2[0]:.2f},{i2[1]:.2f} A{r},{r} 0 {large} 0 {i1[0]:.2f},{i1[1]:.2f} Z")

    # ---- 标签分侧：近垂直的小扇区强制放右侧，避免左上角堆叠 ----
    left, right = [], []
    for it in items:
        it["cs"] = math.cos(math.radians(it["mid"]))
        it["elbow"] = pt(ELB, it["mid"])
        (right if it["cs"] > -0.15 else left).append(it)

    def layout(lst, gap, lo, hi):
        if not lst:
            return
        lst.sort(key=lambda x: x["elbow"][1])
        ys = [x["elbow"][1] for x in lst]
        for i in range(1, len(ys)):
            if ys[i] - ys[i - 1] < gap:
                ys[i] = ys[i - 1] + gap
        over = ys[-1] - hi
        if over > 0:
            ys = [y - over for y in ys]
        if ys[0] < lo:
            d = lo - ys[0]
            ys = [y + d for y in ys]
        for x, y in zip(lst, ys):
            x["ly"] = y

    layout(left, GAP, LO, HI)
    layout(right, GAP, LO, HI)

    # ---- 拼 SVG ----
    out = []
    out.append(f'<svg viewBox="0 0 {VB_W} {VB_H}" width="100%" height="100%" role="img" '
               f'aria-label="{cfg.get("aria", "占比环形图")}">')
    out.append(f'<circle cx="{CX}" cy="{CY}" r="{R + 18}" fill="none" '
               f'stroke="rgba(255,255,255,.04)" stroke-width="1"/>')

    for it in items:
        out.append(f'<path d="{it["path"]}" fill="{it["color"]}" fill-opacity="0.93" '
                   f'stroke="#141418" stroke-width="2.5"/>')

    for it in items:
        ox, oy = pt(R + 3, it["mid"])
        ex, ey = it["elbow"]
        ly = it["ly"]
        side = -1 if it["cs"] <= -0.15 else 1
        anchor = "end" if side < 0 else "start"
        kx = XL if side < 0 else XR
        tx = kx - 9 if side < 0 else kx + 9
        c = it["color"]
        # 引线：弧边 → 标签所在行(与 ly 同高) → 水平到锚点。
        # 用 ly 而不是 ey，避免标签被避让推离后出现斜尾巴。
        out.append(f'<polyline points="{ox:.1f},{oy:.1f} {ex:.1f},{ly:.1f} {kx:.1f},{ly:.1f}" '
                   f'fill="none" stroke="{c}" stroke-opacity="0.6" stroke-width="1.7"/>')
        out.append(f'<circle cx="{ox:.1f}" cy="{oy:.1f}" r="3.6" fill="{c}"/>')
        out.append(f'<text x="{tx:.1f}" y="{ly - 3:.1f}" text-anchor="{anchor}" font-size="19.5" '
                   f'font-weight="650" fill="#EDEAE6">{it["name"]}</text>')
        amt = fmt_amount(it["val"], total)
        out.append(f'<text x="{tx:.1f}" y="{ly + 23:.1f}" text-anchor="{anchor}" font-size="18.5" '
                   f'font-weight="800" fill="{c}">{it["pct"]:.1f}%'
                   f'<tspan font-size="15.5" font-weight="600" fill="#A8A6A1"> · ¥{amt}</tspan></text>')

    out.append(f'<text x="{CX}" y="{CY - 4}" text-anchor="middle" font-size="31" font-weight="800" '
               f'fill="#E8A33D">{cfg["center"]}</text>')
    out.append(f'<text x="{CX}" y="{CY + 24}" text-anchor="middle" font-size="14.5" font-weight="600" '
               f'fill="#94949E" letter-spacing="3">{cfg.get("center_label", "合计")}</text>')
    if cfg.get("sub"):
        out.append(f'<text x="{CX}" y="{CY + 48}" text-anchor="middle" font-size="12.5" '
                   f'fill="#6E6E78">{cfg["sub"]}</text>')
    out.append("</svg>")
    return "\n".join(out), items, total


def audit(items, total):
    """几何自检：估算文字包围盒，检查越界与两两重叠。"""
    def text_w(s, fs):
        w = 0.0
        for ch in s:
            if ord(ch) > 0x2E80:
                w += fs * 1.0
            elif ch in " ·%":
                w += fs * 0.36
            else:
                w += fs * 0.56
        return w

    boxes = []
    for it in items:
        side = -1 if it["cs"] <= -0.15 else 1
        tx = (XL - 9) if side < 0 else (XR + 9)
        ly, c = it["ly"], it["color"]
        for txt, fs, dy in ((it["name"], 19.5, -3),
                            (f'{it["pct"]:.1f}% · ¥{fmt_amount(it["val"], total)}', 18.5, 23)):
            w = text_w(txt, fs)
            x0 = tx - w if side < 0 else tx
            boxes.append((txt, x0, x0 + w, ly + dy - fs * 0.82, ly + dy + fs * 0.22))

    bad = [b for b in boxes
           if b[1] < 4 or b[2] > VB_W - 4 or b[3] < 2 or b[4] > VB_H - 2]
    over = []
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i], boxes[j]
            if a[1] < b[2] and b[1] < a[2] and a[3] < b[4] and b[3] < a[4]:
                over.append((a[0], b[0]))

    print(f"[audit] 扇区 {len(items)} · 文字块 {len(boxes)} · 合计 {total:,.2f}")
    print(f"[audit] 越界 {len(bad)} 处" + ("" if not bad else "：" + str([b[0] for b in bad])))
    print(f"[audit] 重叠 {len(over)} 处" + ("" if not over else "：" + str(over)))
    for it in sorted(items, key=lambda x: -x["pct"]):
        print(f"    {it['name']:<10} {it['pct']:5.1f}%  ¥{fmt_amount(it['val'], total)}")
    return len(bad) == 0 and len(over) == 0


def main():
    ap = argparse.ArgumentParser(description="生成带引线外标注的环形图 SVG")
    ap.add_argument("--input", "-i", help="JSON 文件路径；省略则从 stdin 读")
    ap.add_argument("--out", "-o", default="donut.svg", help="输出 SVG 路径")
    ap.add_argument("--check", action="store_true", help="额外做越界/重叠几何自检")
    a = ap.parse_args()

    raw = open(a.input, encoding="utf-8").read() if a.input else sys.stdin.read()
    cfg = json.loads(raw)
    svg, items, total = build(cfg)
    open(a.out, "w", encoding="utf-8").write(svg)
    print(f"[ok] 已写出 {a.out}（{len(svg)} 字符，{len(items)} 个扇区）")
    if a.check and not audit(items, total):
        sys.exit(1)


if __name__ == "__main__":
    main()
