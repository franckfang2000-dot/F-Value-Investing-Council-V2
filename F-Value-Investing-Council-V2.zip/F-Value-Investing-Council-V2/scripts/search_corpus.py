#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
search_corpus.py — 本地语料检索（可选工具）

目录约定（任意层级都可以，只要文件是 .txt/.md）：
    $VALUE_CORPUS_DIR/
        buffett/xxx.txt
        munger/xxx.txt
        ...

用法：
    export VALUE_CORPUS_DIR=~/Documents/my-corpus
    python3 search_corpus.py "margin of safety"           # 全库搜索
    python3 search_corpus.py "circle of competence" -d buffett -n 3
    python3 search_corpus.py "moat" -i -l                 # 只列命中文件
    python3 search_corpus.py --stats                      # 语料总览

没有本地语料时不必使用本脚本，直接联网取一手材料即可。
"""
import argparse, os, re, sys

DEFAULT_ROOT = os.path.expanduser("~/Documents/ValueCorpus")
EXTS = (".txt", ".md", ".markdown")


def get_root(arg):
    return os.path.abspath(os.path.expanduser(arg or os.environ.get("VALUE_CORPUS_DIR") or DEFAULT_ROOT))


def walk(root, person=None):
    for dirpath, _, files in os.walk(root):
        rel = os.path.relpath(dirpath, root)
        if person and person not in rel.split(os.sep) and person not in rel:
            continue
        for fn in sorted(files):
            if fn.lower().endswith(EXTS):
                yield os.path.join(dirpath, fn)


def print_stats(root):
    if not os.path.isdir(root):
        print(f"[!] 目录不存在：{root}\n    请先 export VALUE_CORPUS_DIR=/你的语料目录")
        return
    print(f"语料根目录：{root}\n")
    print(f"{'目录':<24}{'文件':>6}{'字符':>12}")
    tot_f = tot_c = 0
    for d in sorted(os.listdir(root)):
        dp = os.path.join(root, d)
        if not os.path.isdir(dp) or d.startswith("."):
            continue
        fs = [f for f in walk(dp)]
        c = sum(os.path.getsize(f) for f in fs)
        tot_f += len(fs); tot_c += c
        print(f"{d:<24}{len(fs):>6}{c:>12,}")
    print("-" * 42)
    print(f"{'合计':<24}{tot_f:>6}{tot_c:>12,}")
    print(f"\n折合 {tot_c/1e6:.2f} MB / {tot_f} 个文件")


def main():
    ap = argparse.ArgumentParser(description="本地语料关键词检索")
    ap.add_argument("pattern", nargs="?", help="关键词或正则")
    ap.add_argument("-n", "--context", type=int, default=2, help="上下文行数（默认 2）")
    ap.add_argument("-d", "--person", help="只搜某个子目录，如 buffett")
    ap.add_argument("-i", "--icase", action="store_true", help="忽略大小写")
    ap.add_argument("-l", "--files-only", action="store_true", help="只列命中文件名")
    ap.add_argument("-m", "--max-hits", type=int, default=40, help="最多显示条数（默认 40）")
    ap.add_argument("--root", help=f"语料根目录（默认取 $VALUE_CORPUS_DIR 或 {DEFAULT_ROOT}）")
    ap.add_argument("--stats", action="store_true", help="打印语料总览，不做检索")
    a = ap.parse_args()

    root = get_root(a.root)
    if a.stats:
        print_stats(root)
        return
    if not a.pattern:
        ap.error("需要提供关键词，或使用 --stats")

    if not os.path.isdir(root):
        print(f"[!] 目录不存在：{root}\n    请先 export VALUE_CORPUS_DIR=/你的语料目录")
        sys.exit(1)

    flags = re.I if a.icase else 0
    try:
        rx = re.compile(a.pattern, flags)
    except re.error:
        rx = re.compile(re.escape(a.pattern), flags)

    hits = 0
    matched_files = []
    for path in walk(root, a.person):
        try:
            lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
        except OSError:
            continue
        local = 0
        for i, line in enumerate(lines):
            if rx.search(line):
                local += 1
                hits += 1
                if a.files_only:
                    break
                rel = os.path.relpath(path, root)
                print(f"\n{rel}:{i+1}")
                lo, hi = max(0, i - a.context), min(len(lines), i + a.context + 1)
                for j in range(lo, hi):
                    mark = ">" if j == i else " "
                    print(f" {mark} {lines[j].rstrip()[:200]}")
                if hits >= a.max_hits:
                    print(f"\n[已达上限 {a.max_hits} 条，用 -m 调大]")
                    return
        if local:
            matched_files.append((os.path.relpath(path, root), local))

    if a.files_only:
        for f, n in matched_files:
            print(f"{n:>5}  {f}")
    print(f"\n[共 {hits} 处命中，{len(matched_files)} 个文件]")


if __name__ == "__main__":
    main()
